package com.zybooks.poject

class Stopwatch {

    private var startTime = 0L
    private var stopTime = 0L
    private var running = false

    val lapTimes = mutableListOf<Long>()

    fun start() {
        startTime = System.currentTimeMillis()
        running = true
    }

    fun stop() {
        stopTime = System.currentTimeMillis()
        running = false
    }

    fun reset() {
        startTime = 0L
        stopTime = 0L
        running = false
        lapTimes.clear()
    }

    fun lap() {
        val now = System.currentTimeMillis()
        val lapTime = if (running) {
            now - startTime
        } else {
            stopTime - startTime
        }
        lapTimes.add(lapTime)
    }

    val elapsedTime: Long
        get() = if (running) {
            System.currentTimeMillis() - startTime
        } else {
            stopTime - startTime
        }
}
