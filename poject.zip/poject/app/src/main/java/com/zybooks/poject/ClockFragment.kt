package com.zybooks.poject
import android.app.AlertDialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.zybooks.poject.R
import java.text.SimpleDateFormat
import java.util.*

class ClockFragment : Fragment() {

    private lateinit var clockText: TextView
    private lateinit var timeZoneButton: Button

    // The list of time zones to cycle through
    private val timeZones = listOf("America/Los_Angeles", "GMT", "America/New_York", "Asia/Tokyo", "Australia/Sydney")
    private var currentZoneIndex = 0  // Start with "America/Los_Angeles"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_clock, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        clockText = view.findViewById(R.id.clock_text)
        timeZoneButton = view.findViewById(R.id.time_zone_button)

        timeZoneButton.setOnClickListener {
            // Show a dialog with a list of time zones
            AlertDialog.Builder(requireContext()).apply {
                setTitle("Select a time zone")
                setItems(timeZones.toTypedArray()) { _, which ->
                    currentZoneIndex = which
                    updateClock()
                }
                show()
            }
        }

        // Call updateClock() immediately to show the current time
        updateClock()

        // Start a new timer that updates the clock every second
        Timer().scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                activity?.runOnUiThread { updateClock() }
            }
        }, 0, 1000)
    }

    private fun updateClock() {
        val format = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())
        format.timeZone = TimeZone.getTimeZone(timeZones[currentZoneIndex])
        clockText.text = format.format(Date())
        timeZoneButton.text = format.timeZone.displayName
    }
}
