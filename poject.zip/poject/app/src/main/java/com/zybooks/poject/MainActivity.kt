package com.zybooks.poject

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Set up the ViewPager2 and TabLayout
        val viewPager: ViewPager2 = findViewById(R.id.view_pager)
        val tabLayout: TabLayout = findViewById(R.id.tab_layout)

        // Create a new FragmentStateAdapter and set it to the ViewPager2
        viewPager.adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount() = 4

            override fun createFragment(position: Int) = when(position) {
                0 -> CountdownFragment()
                1 -> ClockFragment()
                2 -> AlarmFragment()
                else -> StopwatchFragment()
            }
        }

        // Set up the TabLayoutMediator to sync the TabLayout and ViewPager2
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = when(position) {
                0 -> "Countdown"
                1 -> "Clock"
                2 -> "Alarm"
                else -> "Stopwatch"
            }
        }.attach()
    }
}
