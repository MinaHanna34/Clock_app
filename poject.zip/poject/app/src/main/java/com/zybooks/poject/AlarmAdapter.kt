package com.zybooks.poject

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.TimePicker
import androidx.recyclerview.widget.RecyclerView

class AlarmAdapter(
    private val alarms: List<Alarm>,
    private val onAlarmTimeSet: (Alarm, Int, Int) -> Unit,
    private val onDeleteAlarm: (Alarm) -> Unit
) : RecyclerView.Adapter<AlarmAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val timePicker: TimePicker = itemView.findViewById(R.id.time_picker)
        val deleteButton: Button = itemView.findViewById(R.id.delete_button)
        val timeText: TextView = itemView.findViewById(R.id.time_text)

        fun bind(alarm: Alarm, onAlarmTimeSet: (Alarm, Int, Int) -> Unit, onDeleteAlarm: (Alarm) -> Unit) {
            timePicker.hour = alarm.hour
            timePicker.minute = alarm.minute
            timeText.text = "${String.format("%02d", alarm.hour)}:${String.format("%02d", alarm.minute)}"
            timePicker.setOnTimeChangedListener { _, hour, minute ->
                onAlarmTimeSet(alarm, hour, minute)
                timeText.text = "${String.format("%02d", hour)}:${String.format("%02d", minute)}"
            }

            deleteButton.setOnClickListener {
                onDeleteAlarm(alarm)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val itemView = inflater.inflate(R.layout.item_alarm, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(alarms[position], onAlarmTimeSet, onDeleteAlarm)
    }

    override fun getItemCount() = alarms.size
}
