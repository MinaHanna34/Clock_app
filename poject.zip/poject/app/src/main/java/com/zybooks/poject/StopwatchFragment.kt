package com.zybooks.poject

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.TimeUnit

class StopwatchFragment : Fragment() {

    private lateinit var stopwatch: Stopwatch
    private lateinit var stopwatchAdapter: StopwatchAdapter
    private lateinit var stopwatchTimeText: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val updateRunnable = object : Runnable {
        override fun run() {
            updateStopwatchTime()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_stopwatch, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        stopwatch = Stopwatch()
        stopwatchAdapter = StopwatchAdapter(stopwatch.lapTimes)

        val recyclerView: RecyclerView = view.findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = stopwatchAdapter

        stopwatchTimeText = view.findViewById(R.id.stopwatch_time_text)

        val startButton: Button = view.findViewById(R.id.start_button)
        startButton.setOnClickListener {
            stopwatch.start()
            handler.post(updateRunnable)
        }

        val stopButton: Button = view.findViewById(R.id.stop_button)
        stopButton.setOnClickListener {
            stopwatch.stop()
            handler.removeCallbacks(updateRunnable)
            updateStopwatchTime()
        }

        val resetButton: Button = view.findViewById(R.id.reset_button)
        resetButton.setOnClickListener {
            stopwatch.reset()
            stopwatchAdapter.notifyDataSetChanged()
            updateStopwatchTime()
        }

        val lapButton: Button = view.findViewById(R.id.lap_button)
        lapButton.setOnClickListener {
            stopwatch.lap()
            stopwatchAdapter.notifyItemInserted(stopwatch.lapTimes.size - 1)
        }

        updateStopwatchTime()
    }

    private fun updateStopwatchTime() {
        val millis = stopwatch.elapsedTime
        val hours = TimeUnit.MILLISECONDS.toHours(millis)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis) % TimeUnit.HOURS.toMinutes(1)
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % TimeUnit.MINUTES.toSeconds(1)
        stopwatchTimeText.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
    }
}
