package com.zybooks.poject

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

data class Alarm(val id: Int, var hour: Int, var minute: Int, var isEnabled: Boolean)
class AlarmFragment : Fragment() {

    private lateinit var alarmManager: AlarmManager
    private val alarms: MutableList<Alarm> = mutableListOf()
    private val pendingIntents: MutableMap<Int, PendingIntent> = mutableMapOf()
    private lateinit var alarmAdapter: AlarmAdapter
    private lateinit var currentTimeText: TextView
    private lateinit var alarmTimeText: TextView
    private lateinit var recyclerView: RecyclerView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_alarm, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        alarmManager = requireActivity().getSystemService(Context.ALARM_SERVICE) as AlarmManager

        alarmAdapter = AlarmAdapter(alarms, ::setAlarmTime, ::deleteAlarm)
        recyclerView = view.findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = alarmAdapter

        val addAlarmButton: Button = view.findViewById(R.id.add_alarm_button)
        addAlarmButton.setOnClickListener {
            addAlarm(12, 0) // example to add a default alarm at 12:00, you should use TimePickerDialog to get these values
        }

        currentTimeText = view.findViewById(R.id.current_time_text)
        alarmTimeText = view.findViewById(R.id.alarm_time_text)
        val addTimeButton: Button = view.findViewById(R.id.add_time_button)
        addTimeButton.setOnClickListener {
            // Set the time for the alarm here.
            // You might want to use a TimePickerDialog to get the time from the user.
            val calendar = Calendar.getInstance()
            setAlarmTime(alarms[0], calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE))
        }

        updateCurrentTime()
    }

    private fun addAlarm(hour: Int, minute: Int) {
        val alarm = Alarm(generateUniqueId(), hour, minute, true)
        alarms.add(alarm)
        alarmAdapter.notifyItemInserted(alarms.size - 1)
        setAlarm(alarm)
        updateAlarmTime(alarm)
    }

    private fun deleteAlarm(alarm: Alarm) {
        alarms.remove(alarm)
        alarmAdapter.notifyDataSetChanged()
        cancelAlarm(alarm)
    }

    private fun setAlarm(alarm: Alarm) {
        val alarmIntent = Intent(context, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(context, alarm.id, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        pendingIntents[alarm.id] = pendingIntent
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, alarm.hour)
            set(Calendar.MINUTE, alarm.minute)
        }
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
    }

    private fun cancelAlarm(alarm: Alarm) {
        val pendingIntent = pendingIntents[alarm.id]
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntents.remove(alarm.id)
        }
    }

    private fun generateUniqueId(): Int {
        var id = 1
        while (alarms.any { it.id == id }) {
            id++
        }
        return id
    }

    private fun setAlarmTime(alarm: Alarm, hour: Int, minute: Int) {
        alarm.hour = hour
        alarm.minute = minute
        if (alarm.isEnabled) {
            setAlarm(alarm)
        }
        updateAlarmTime(alarm)
        recyclerView.post { alarmAdapter.notifyDataSetChanged() }
    }

    private fun updateCurrentTime() {
        val currentTime = Calendar.getInstance()
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        currentTimeText.text = timeFormat.format(currentTime.time)
    }

    private fun updateAlarmTime(alarm: Alarm) {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, alarm.hour)
        calendar.set(Calendar.MINUTE, alarm.minute)
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        alarmTimeText.text = timeFormat.format(calendar.time)
    }
}
