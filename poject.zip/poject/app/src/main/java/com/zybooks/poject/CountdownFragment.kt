package com.zybooks.poject
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.zybooks.poject.R

class CountdownFragment : Fragment() {

    private lateinit var countdownText: TextView
    private lateinit var hoursInput: EditText
    private lateinit var minutesInput: EditText
    private lateinit var secondsInput: EditText
    private lateinit var pauseButton: Button
    private var countDownTimer: CountDownTimer? = null
    private var remainingTime: Long = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_countdown, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        countdownText = view.findViewById(R.id.countdown_text)
        hoursInput = view.findViewById(R.id.hours_input)
        minutesInput = view.findViewById(R.id.minutes_input)
        secondsInput = view.findViewById(R.id.seconds_input)

        val startButton: Button = view.findViewById(R.id.start_button)
        pauseButton = view.findViewById(R.id.pause_button)

        startButton.setOnClickListener {
            val hoursInMillis = (hoursInput.text.toString().toLongOrNull() ?: 0) * 60 * 60 * 1000 // Convert hours to milliseconds
            val minutesInMillis = (minutesInput.text.toString().toLongOrNull() ?: 0) * 60 * 1000 // Convert minutes to milliseconds
            val secondsInMillis = (secondsInput.text.toString().toLongOrNull() ?: 0) * 1000 // Convert seconds to milliseconds

            val totalMillis = hoursInMillis + minutesInMillis + secondsInMillis

            startCountdown(totalMillis)
        }

        pauseButton.setOnClickListener {
            if (pauseButton.text == "Pause") {
                pauseButton.text = "Resume"
                countDownTimer?.cancel()
            } else {
                pauseButton.text = "Pause"
                startCountdown(remainingTime)
            }
        }
    }

    private fun startCountdown(totalMillis: Long) {
        remainingTime = totalMillis
        countDownTimer?.cancel() // Cancel any previous countdown

        countDownTimer = object : CountDownTimer(totalMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                remainingTime = millisUntilFinished
                val seconds = (remainingTime / 1000) % 60
                val minutes = (remainingTime / (1000 * 60)) % 60
                val hours = (remainingTime / (1000 * 60 * 60)) % 24
                countdownText.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                if (millisUntilFinished <= 30000) {
                    countdownText.setTextColor(Color.RED)
                } else {
                    countdownText.setTextColor(Color.BLACK)
                }
            }

            override fun onFinish() {
                countdownText.text = "Finished!"
            }
        }
        countDownTimer?.start()
    }
}
