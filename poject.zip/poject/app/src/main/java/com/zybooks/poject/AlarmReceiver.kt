package com.zybooks.poject

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.widget.Toast

class AlarmReceiver : BroadcastReceiver() {

    private var mediaPlayer: MediaPlayer? = null

    override fun onReceive(context: Context, intent: Intent) {
        Toast.makeText(context, "Alarm!", Toast.LENGTH_SHORT).show()

        // Stop the previous sound if it's still playing
        mediaPlayer?.stop()
        mediaPlayer?.release()

        mediaPlayer = MediaPlayer.create(context, R.raw.sound)
        mediaPlayer?.start()
    }
}
